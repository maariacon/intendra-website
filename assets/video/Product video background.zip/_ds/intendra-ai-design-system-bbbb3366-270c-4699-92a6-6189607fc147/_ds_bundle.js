/* @ds-bundle: {"format":4,"namespace":"IntendraAIDesignSystem_bbbb33","components":[{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"Tag","sourcePath":"components/feedback/Tag.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"Dialog","sourcePath":"components/surfaces/Dialog.jsx"}],"sourceHashes":{"components/feedback/Badge.jsx":"a449568b62fc","components/feedback/Tag.jsx":"331df7266814","components/feedback/Toast.jsx":"86e5ad60e5b5","components/feedback/Tooltip.jsx":"77411f7fad9c","components/forms/Button.jsx":"776cd1f69d84","components/forms/Checkbox.jsx":"6b3b155cb2d8","components/forms/IconButton.jsx":"25f15ac79bd9","components/forms/Input.jsx":"e34259bf2d8f","components/forms/Radio.jsx":"ae6d72e9f54f","components/forms/Select.jsx":"21cb11ac9330","components/forms/Switch.jsx":"51fd30ae881e","components/navigation/Tabs.jsx":"27e08173f3d1","components/surfaces/Card.jsx":"de29530304e6","components/surfaces/Dialog.jsx":"3ff191cbf8b9","ui_kits/dashboard/Dashboard.jsx":"6823991bb440"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.IntendraAIDesignSystem_bbbb33 = window.IntendraAIDesignSystem_bbbb33 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/feedback/Badge.jsx
try { (() => {
const tones = {
  neutral: {
    background: "var(--surface-sunken)",
    color: "var(--text-secondary)"
  },
  brand: {
    background: "rgba(27,234,135,0.16)",
    color: "#0E7A47"
  },
  success: {
    background: "var(--success-surface)",
    color: "#0E7A47"
  },
  warning: {
    background: "var(--warning-surface)",
    color: "#6B7A0F"
  },
  info: {
    background: "var(--info-surface)",
    color: "#0E6E80"
  },
  danger: {
    background: "var(--danger-surface)",
    color: "var(--danger-fg)"
  }
};
function Badge({
  children,
  tone = "neutral"
}) {
  const t = tones[tone] || tones.neutral;
  return React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-caption)",
      fontWeight: "var(--weight-semibold)",
      padding: "3px 9px",
      borderRadius: "var(--radius-pill)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      ...t
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tag.jsx
try { (() => {
function Tag({
  children,
  onRemove
}) {
  return React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body-s)",
      color: "var(--text-primary)",
      background: "var(--surface-sunken)",
      border: "1px solid var(--border-default)",
      padding: "4px 8px 4px 10px",
      borderRadius: "var(--radius-sm)"
    }
  }, children, onRemove && React.createElement("button", {
    onClick: onRemove,
    "aria-label": "Remove",
    style: {
      border: "none",
      background: "transparent",
      color: "var(--text-muted)",
      cursor: "pointer",
      fontSize: 14,
      lineHeight: 1,
      padding: 0
    }
  }, "\u00D7"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const toneBorder = {
  info: "var(--color-aqua-circuit)",
  success: "var(--accent)",
  warning: "var(--color-lime-insight)",
  danger: "var(--danger-fg)"
};
function Toast({
  children,
  tone = "info",
  onClose
}) {
  return React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 10,
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body-s)",
      color: "var(--text-primary)",
      background: "var(--surface-card)",
      borderLeft: `3px solid ${toneBorder[tone] || toneBorder.info}`,
      boxShadow: "var(--shadow-md)",
      borderRadius: "var(--radius-sm)",
      padding: "12px 14px",
      maxWidth: 340
    }
  }, React.createElement("span", {
    style: {
      flex: 1
    }
  }, children), onClose && React.createElement("button", {
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      border: "none",
      background: "transparent",
      color: "var(--text-muted)",
      cursor: "pointer",
      fontSize: 14
    }
  }, "\u00D7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  children,
  label
}) {
  const [show, setShow] = React.useState(false);
  return React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex"
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false)
  }, children, show && React.createElement("span", {
    style: {
      position: "absolute",
      bottom: "calc(100% + 6px)",
      left: "50%",
      transform: "translateX(-50%)",
      background: "var(--color-obsidian)",
      color: "#fff",
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-caption)",
      padding: "5px 9px",
      borderRadius: "var(--radius-xs)",
      whiteSpace: "nowrap",
      boxShadow: "var(--shadow-sm)",
      zIndex: 10
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
const sizes = {
  sm: {
    padding: "6px 12px",
    fontSize: "var(--text-body-s)",
    height: 32
  },
  md: {
    padding: "9px 16px",
    fontSize: "var(--text-body)",
    height: 40
  },
  lg: {
    padding: "12px 20px",
    fontSize: "var(--text-body-l)",
    height: 48
  }
};
const variants = {
  primary: {
    background: "var(--accent)",
    color: "var(--text-on-brand)",
    border: "1px solid transparent"
  },
  secondary: {
    background: "var(--color-obsidian)",
    color: "#fff",
    border: "1px solid transparent"
  },
  outline: {
    background: "transparent",
    color: "var(--text-primary)",
    border: "1px solid var(--border-strong)"
  },
  ghost: {
    background: "transparent",
    color: "var(--text-primary)",
    border: "1px solid transparent"
  },
  danger: {
    background: "var(--danger-fg)",
    color: "#fff",
    border: "1px solid transparent"
  }
};
function Button({
  children,
  variant = "primary",
  size = "md",
  disabled = false,
  fullWidth = false,
  onClick,
  type = "button"
}) {
  const v = variants[variant] || variants.primary;
  const s = sizes[size] || sizes.md;
  return React.createElement("button", {
    type,
    disabled,
    onClick,
    style: {
      fontFamily: "var(--font-body)",
      fontWeight: "var(--weight-semibold)",
      borderRadius: "var(--radius-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      transition: "background var(--duration-fast) var(--ease-standard), transform var(--duration-fast) var(--ease-standard)",
      width: fullWidth ? "100%" : undefined,
      opacity: disabled ? 0.45 : 1,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      ...v,
      ...s
    }
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  onChange,
  disabled = false
}) {
  return React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      fontFamily: "var(--font-body)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1
    }
  }, React.createElement("input", {
    type: "checkbox",
    checked,
    disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      width: 16,
      height: 16,
      accentColor: "var(--accent)"
    }
  }), React.createElement("span", {
    style: {
      fontSize: "var(--text-body-s)",
      color: "var(--text-primary)"
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function IconButton({
  icon,
  label,
  size = "md",
  variant = "ghost",
  onClick,
  disabled = false
}) {
  const dim = {
    sm: 28,
    md: 36,
    lg: 44
  }[size] || 36;
  const styles = {
    ghost: {
      background: "transparent",
      color: "var(--text-primary)",
      border: "1px solid transparent"
    },
    outline: {
      background: "transparent",
      color: "var(--text-primary)",
      border: "1px solid var(--border-default)"
    },
    filled: {
      background: "var(--surface-sunken)",
      color: "var(--text-primary)",
      border: "1px solid transparent"
    }
  };
  return React.createElement("button", {
    "aria-label": label,
    title: label,
    onClick,
    disabled,
    style: {
      width: dim,
      height: dim,
      borderRadius: "var(--radius-sm)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      transition: "background var(--duration-fast) var(--ease-standard)",
      ...(styles[variant] || styles.ghost)
    }
  }, React.createElement("img", {
    src: icon,
    alt: "",
    style: {
      width: dim * 0.5,
      height: dim * 0.5
    }
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input({
  label,
  placeholder,
  value,
  onChange,
  type = "text",
  helpText,
  error,
  disabled = false
}) {
  return React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      fontFamily: "var(--font-body)",
      width: "100%"
    }
  }, label && React.createElement("span", {
    style: {
      fontSize: "var(--text-body-s)",
      fontWeight: "var(--weight-medium)",
      color: "var(--text-primary)"
    }
  }, label), React.createElement("input", {
    type,
    placeholder,
    value,
    disabled,
    onChange: e => onChange && onChange(e.target.value),
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body)",
      padding: "9px 12px",
      borderRadius: "var(--radius-sm)",
      border: `1px solid ${error ? "var(--danger-fg)" : "var(--border-default)"}`,
      background: disabled ? "var(--surface-sunken)" : "var(--surface-card)",
      color: "var(--text-primary)",
      outline: "none"
    }
  }), error ? React.createElement("span", {
    style: {
      fontSize: "var(--text-caption)",
      color: "var(--danger-fg)"
    }
  }, error) : helpText ? React.createElement("span", {
    style: {
      fontSize: "var(--text-caption)",
      color: "var(--text-muted)"
    }
  }, helpText) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  name,
  label,
  value,
  checked,
  onChange,
  disabled = false
}) {
  return React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      fontFamily: "var(--font-body)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1
    }
  }, React.createElement("input", {
    type: "radio",
    name,
    value,
    checked,
    disabled,
    onChange: () => onChange && onChange(value),
    style: {
      width: 16,
      height: 16,
      accentColor: "var(--accent)"
    }
  }), React.createElement("span", {
    style: {
      fontSize: "var(--text-body-s)",
      color: "var(--text-primary)"
    }
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  value,
  onChange,
  options = [],
  disabled = false
}) {
  return React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      fontFamily: "var(--font-body)",
      width: "100%"
    }
  }, label && React.createElement("span", {
    style: {
      fontSize: "var(--text-body-s)",
      fontWeight: "var(--weight-medium)",
      color: "var(--text-primary)"
    }
  }, label), React.createElement("select", {
    value,
    disabled,
    onChange: e => onChange && onChange(e.target.value),
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body)",
      padding: "9px 12px",
      borderRadius: "var(--radius-sm)",
      border: "1px solid var(--border-default)",
      background: disabled ? "var(--surface-sunken)" : "var(--surface-card)",
      color: "var(--text-primary)"
    }
  }, options.map(o => React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked,
  onChange,
  disabled = false
}) {
  return React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      fontFamily: "var(--font-body)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1
    }
  }, React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 38,
      height: 22,
      borderRadius: "var(--radius-pill)",
      background: checked ? "var(--accent)" : "var(--border-default)",
      position: "relative",
      transition: "background var(--duration-fast) var(--ease-standard)",
      flexShrink: 0
    }
  }, React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: checked ? 18 : 2,
      width: 18,
      height: 18,
      borderRadius: "50%",
      background: "#fff",
      boxShadow: "var(--shadow-xs)",
      transition: "left var(--duration-fast) var(--ease-standard)"
    }
  })), label && React.createElement("span", {
    style: {
      fontSize: "var(--text-body-s)",
      color: "var(--text-primary)"
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  tabs = [],
  value,
  onChange
}) {
  return React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      borderBottom: "1px solid var(--border-default)",
      fontFamily: "var(--font-body)"
    }
  }, tabs.map(t => React.createElement("button", {
    key: t.value,
    onClick: () => onChange && onChange(t.value),
    style: {
      border: "none",
      background: "transparent",
      padding: "10px 14px",
      fontSize: "var(--text-body-s)",
      fontWeight: "var(--weight-medium)",
      color: value === t.value ? "var(--text-primary)" : "var(--text-secondary)",
      borderBottom: value === t.value ? "2px solid var(--accent)" : "2px solid transparent",
      marginBottom: -1,
      cursor: "pointer"
    }
  }, t.label)));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function Card({
  children,
  padding = "20px"
}) {
  return React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-sm)",
      padding,
      fontFamily: "var(--font-body)",
      color: "var(--text-primary)"
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Dialog.jsx
try { (() => {
function Dialog({
  open,
  title,
  children,
  onClose,
  actions
}) {
  if (!open) return null;
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(40,40,45,0.45)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 100
    },
    onClick: onClose
  }, React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "var(--surface-card)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-lg)",
      padding: 24,
      minWidth: 360,
      maxWidth: 480,
      fontFamily: "var(--font-body)",
      color: "var(--text-primary)"
    }
  }, title && React.createElement("h3", {
    style: {
      margin: "0 0 12px",
      fontSize: "var(--text-h3)",
      fontWeight: "var(--weight-semibold)"
    }
  }, title), React.createElement("div", {
    style: {
      fontSize: "var(--text-body-s)",
      color: "var(--text-secondary)",
      marginBottom: 20
    }
  }, children), actions && React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 10
    }
  }, actions)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Dialog.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Dashboard.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Card,
  Tabs,
  Input,
  Toast
} = window.IntendraAIDesignSystem_bbbb33;
const nav = [{
  key: "overview",
  label: "Overview",
  icon: "layout-dashboard"
}, {
  key: "signals",
  label: "Signals",
  icon: "radar"
}, {
  key: "accounts",
  label: "Accounts",
  icon: "users"
}, {
  key: "actions",
  label: "Actions",
  icon: "list-checks"
}, {
  key: "settings",
  label: "Settings",
  icon: "settings"
}];
function Icon({
  name,
  size = 18,
  color = "currentColor"
}) {
  return React.createElement("img", {
    src: `https://unpkg.com/lucide-static/icons/${name}.svg`,
    style: {
      width: size,
      height: size,
      filter: color === "#fff" ? "invert(1)" : undefined
    },
    alt: ""
  });
}
function Sidebar({
  active,
  onSelect
}) {
  return React.createElement("div", {
    style: {
      width: 220,
      background: "var(--color-obsidian)",
      color: "var(--text-inverse-strong)",
      display: "flex",
      flexDirection: "column",
      padding: "20px 12px",
      boxSizing: "border-box",
      gap: 4,
      flexShrink: 0
    }
  }, React.createElement("img", {
    src: "../../assets/logo/wordmark-brilliant-green.jpg",
    style: {
      width: 130,
      marginBottom: 28,
      marginLeft: 8
    }
  }), nav.map(n => React.createElement("button", {
    key: n.key,
    onClick: () => onSelect(n.key),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "9px 10px",
      borderRadius: "var(--radius-sm)",
      border: "none",
      background: active === n.key ? "rgba(27,234,135,0.14)" : "transparent",
      color: active === n.key ? "var(--color-brilliant-green)" : "var(--color-stone)",
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body-s)",
      fontWeight: "var(--weight-medium)",
      cursor: "pointer",
      textAlign: "left"
    }
  }, React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, React.createElement("img", {
    src: `https://unpkg.com/lucide-static/icons/${n.icon}.svg`,
    style: {
      width: 16,
      height: 16,
      filter: "invert(1)",
      opacity: active === n.key ? 1 : 0.75
    }
  })), n.label)));
}
function TopBar({
  title,
  subtitle
}) {
  return React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "18px 28px",
      borderBottom: "1px solid var(--border-default)"
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: "var(--text-h1)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-primary)"
    }
  }, title), subtitle && React.createElement("div", {
    style: {
      fontSize: "var(--text-body-s)",
      color: "var(--text-secondary)",
      marginTop: 2
    }
  }, subtitle)), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center"
    }
  }, React.createElement(IconButton, {
    icon: "https://unpkg.com/lucide-static/icons/bell.svg",
    label: "Notifications",
    variant: "outline"
  }), React.createElement("div", {
    style: {
      width: 34,
      height: 34,
      borderRadius: "50%",
      background: "var(--color-lime-insight)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: 700,
      fontSize: 13,
      color: "var(--text-primary)"
    }
  }, "MC")));
}
function MetricCard({
  label,
  value,
  delta,
  tone
}) {
  return React.createElement(Card, null, React.createElement("div", {
    style: {
      fontSize: "var(--text-caption)",
      color: "var(--text-muted)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wide)",
      marginBottom: 8
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: "var(--text-display-m)",
      fontWeight: "var(--weight-bold)",
      color: "var(--text-primary)"
    }
  }, value), React.createElement("div", {
    style: {
      fontSize: "var(--text-body-s)",
      color: tone === "up" ? "#0E7A47" : "var(--danger-fg)",
      marginTop: 6,
      fontWeight: "var(--weight-medium)"
    }
  }, delta));
}
const signals = [{
  id: "SIG-1042",
  account: "Northwind Retail",
  type: "Churn risk",
  score: 0.87,
  tone: "danger"
}, {
  id: "SIG-1041",
  account: "Bluepeak Logistics",
  type: "Upsell signal",
  score: 0.74,
  tone: "success"
}, {
  id: "SIG-1039",
  account: "Fenwick & Co",
  type: "Support friction",
  score: 0.61,
  tone: "warning"
}, {
  id: "SIG-1035",
  account: "Origin Health",
  type: "Churn risk",
  score: 0.58,
  tone: "warning"
}];
function SignalsTable() {
  return React.createElement(Card, {
    padding: "0"
  }, React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      fontFamily: "var(--font-body)"
    }
  }, React.createElement("thead", null, React.createElement("tr", {
    style: {
      textAlign: "left",
      fontSize: "var(--text-caption)",
      color: "var(--text-muted)",
      textTransform: "uppercase"
    }
  }, ["Signal", "Account", "Type", "Score", ""].map(h => React.createElement("th", {
    key: h,
    style: {
      padding: "12px 16px",
      borderBottom: "1px solid var(--border-default)",
      fontWeight: "var(--weight-medium)"
    }
  }, h)))), React.createElement("tbody", null, signals.map(s => React.createElement("tr", {
    key: s.id
  }, React.createElement("td", {
    style: {
      padding: "14px 16px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-body-s)",
      color: "var(--text-secondary)",
      borderBottom: "1px solid var(--border-default)"
    }
  }, s.id), React.createElement("td", {
    style: {
      padding: "14px 16px",
      fontSize: "var(--text-body-s)",
      color: "var(--text-primary)",
      borderBottom: "1px solid var(--border-default)"
    }
  }, s.account), React.createElement("td", {
    style: {
      padding: "14px 16px",
      fontSize: "var(--text-body-s)",
      color: "var(--text-primary)",
      borderBottom: "1px solid var(--border-default)"
    }
  }, s.type), React.createElement("td", {
    style: {
      padding: "14px 16px",
      borderBottom: "1px solid var(--border-default)"
    }
  }, React.createElement(Badge, {
    tone: s.tone
  }, s.score.toFixed(2))), React.createElement("td", {
    style: {
      padding: "14px 16px",
      borderBottom: "1px solid var(--border-default)",
      textAlign: "right"
    }
  }, React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "View")))))));
}
function OverviewScreen() {
  return React.createElement("div", {
    style: {
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 16
    }
  }, React.createElement(MetricCard, {
    label: "Active accounts",
    value: "3,204",
    delta: "+4.2% vs last month",
    tone: "up"
  }), React.createElement(MetricCard, {
    label: "Open signals",
    value: "128",
    delta: "+18 this week",
    tone: "down"
  }), React.createElement(MetricCard, {
    label: "Actions taken",
    value: "412",
    delta: "+9.1% vs last month",
    tone: "up"
  }), React.createElement(MetricCard, {
    label: "At-risk revenue",
    value: "$186K",
    delta: "-2.4% vs last month",
    tone: "up"
  })), React.createElement("div", {
    style: {
      fontSize: "var(--text-h3)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-primary)"
    }
  }, "Recent signals"), React.createElement(SignalsTable, null));
}
function SignalsScreen() {
  const [tab, setTab] = React.useState("all");
  return React.createElement("div", {
    style: {
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, React.createElement(Tabs, {
    tabs: [{
      value: "all",
      label: "All signals"
    }, {
      value: "churn",
      label: "Churn risk"
    }, {
      value: "upsell",
      label: "Upsell"
    }],
    value: tab,
    onChange: setTab
  }), React.createElement(SignalsTable, null));
}
const actions = [{
  title: "Reach out to Northwind Retail",
  detail: "Churn risk score jumped 0.31 in 7 days.",
  tone: "danger"
}, {
  title: "Offer expansion pricing to Bluepeak Logistics",
  detail: "Usage up 42% over baseline.",
  tone: "success"
}, {
  title: "Escalate Fenwick & Co support thread",
  detail: "3 unresolved tickets flagged as friction.",
  tone: "warning"
}];
function ActionsScreen() {
  return React.createElement("div", {
    style: {
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, actions.map((a, i) => React.createElement(Card, {
    key: i
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      gap: 12
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: "var(--text-body)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-primary)"
    }
  }, a.title), React.createElement("div", {
    style: {
      fontSize: "var(--text-body-s)",
      color: "var(--text-secondary)",
      marginTop: 4
    }
  }, a.detail)), React.createElement(Badge, {
    tone: a.tone
  }, a.tone === "danger" ? "Urgent" : a.tone === "success" ? "Opportunity" : "Watch")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginTop: 14
    }
  }, React.createElement(Button, {
    size: "sm",
    variant: "primary"
  }, "Mark done"), React.createElement(Button, {
    size: "sm",
    variant: "ghost"
  }, "Snooze")))));
}
function AccountsScreen() {
  const accounts = ["Northwind Retail", "Bluepeak Logistics", "Fenwick & Co", "Origin Health", "Vantage Supply"];
  return React.createElement("div", {
    style: {
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, React.createElement(Input, {
    label: "Search accounts",
    placeholder: "Search by name"
  }), React.createElement(Card, {
    padding: "0"
  }, accounts.map((a, i) => React.createElement("div", {
    key: a,
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "14px 16px",
      borderBottom: i < accounts.length - 1 ? "1px solid var(--border-default)" : "none"
    }
  }, React.createElement("span", {
    style: {
      fontSize: "var(--text-body-s)",
      color: "var(--text-primary)"
    }
  }, a), React.createElement(Badge, {
    tone: i === 0 ? "danger" : i === 1 ? "success" : "neutral"
  }, i === 0 ? "At risk" : i === 1 ? "Growing" : "Stable")))));
}
function SettingsScreen() {
  return React.createElement("div", {
    style: {
      padding: 28,
      maxWidth: 420,
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, React.createElement(Input, {
    label: "Workspace name",
    value: "Intendra AI"
  }), React.createElement(Input, {
    label: "Signal alert threshold",
    value: "0.65"
  }));
}
function Dashboard() {
  const [active, setActive] = React.useState("overview");
  const [toast, setToast] = React.useState(true);
  const titles = {
    overview: ["Overview", "Customer behavior at a glance"],
    signals: ["Signals", "Feedback and behavior turned into scored signals"],
    accounts: ["Accounts", "Every customer, one health view"],
    actions: ["Actions", "What to do next, ranked by impact"],
    settings: ["Settings", "Workspace preferences"]
  };
  const screens = {
    overview: OverviewScreen,
    signals: SignalsScreen,
    accounts: AccountsScreen,
    actions: ActionsScreen,
    settings: SettingsScreen
  };
  const Screen = screens[active];
  return React.createElement("div", {
    style: {
      display: "flex",
      height: "100%",
      fontFamily: "var(--font-body)",
      background: "var(--bg-canvas)"
    }
  }, React.createElement(Sidebar, {
    active,
    onSelect: setActive
  }), React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      overflow: "auto",
      position: "relative"
    }
  }, React.createElement(TopBar, {
    title: titles[active][0],
    subtitle: titles[active][1]
  }), React.createElement(Screen, null), toast && React.createElement("div", {
    style: {
      position: "fixed",
      top: 20,
      right: 20
    }
  }, React.createElement(Toast, {
    tone: "success",
    onClose: () => setToast(false)
  }, "3 new signals synced."))));
}
window.Dashboard = Dashboard;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Dashboard.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Dialog = __ds_scope.Dialog;

})();
