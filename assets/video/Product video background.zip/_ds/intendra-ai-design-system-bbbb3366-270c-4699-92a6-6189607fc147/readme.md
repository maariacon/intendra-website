
# Intendra AI Design System

Intendra AI is a **Customer Behavior Intelligence Platform** — it turns customer feedback and behavior signals into concrete business actions. The brand line is *"Eliminating friction. Activating insight."*

## Sources
- `uploads/intendra_brand guidelines_100625.pdf` — official 13-page brand guideline (wordmark, symbol, color, type, placement rules). Fully readable; this is the ground truth for tokens below.
- `uploads/INTRO DECK to share Partners.pptx.pdf` — a 20-page Canva-exported partner intro deck. **Could not be read**: it has no extractable text layer (image-only export) and its pages timed out on raster extraction (large embedded images). No product screens or copy were recovered from it. If you can re-export it with a text layer, or share it another way, I can mine it for messaging and any product screenshots it contains.
- `uploads/Intendra AI_RGB_{wordmark,symbol}_{brilliant green,obsidian,stone,white}.jpg` — official logo files, all copied into `assets/logo/`.
- `uploads/Reveal Big.png` — a colorful starburst/asterisk graphic (teal, lime, cyan, violet bars radiating from a dark center with a small light dot) — copied into `assets/illustration/`. Likely a generic brand/hero illustration; no other context on its usage was provided.
- No Figma file, GitHub repo, or product codebase was attached. **No component library or product UI source exists** — the components below are a standard, from-scratch set sized to the brand (per design-system authoring rules when no source defines an inventory), and the UI kit is a plausible recreation of a "customer behavior intelligence" dashboard based on the company description only, not a copy of a real screen.

## Products
Only one product surface is implied by the company description: a **web dashboard** for monitoring customer feedback/behavior and turning it into action. `ui_kits/dashboard/` contains a cosmetic recreation of what such a product plausibly looks like, built from the brand tokens — **not** sourced from a real Intendra AI screen (none was provided).

## Intentional additions
- Full standard component set (Button, IconButton, Input, Select, Checkbox, Radio, Switch, Card, Badge, Tag, Tabs, Dialog, Toast, Tooltip) — authored from scratch since no Figma/codebase defines a component inventory.
- `--color-danger` / `--color-danger-surface` tokens — the brand palette has no red/error color; derived via oklch to stay tonally consistent (see Visual Foundations → Colors).
- Body/display typeface substituted (see Visual Foundations → Type) — flagged for follow-up.

## Content Fundamentals
- **Tagline / voice**: *"Eliminating friction. Activating insight."* — two short imperative-noun fragments, sentence case, period-terminated. Confident, compact, no exclamation points.
- **Tone**: analytical and composed rather than hypey. Words used in the brand's own color/type descriptions — "energetic," "sophisticated," "grounding," "modern," "tech-focused" — sit closer to *precise and capable* than *playful*. Favor short declarative sentences over long marketing copy.
- **Casing**: sentence case throughout (the wordmark itself is lowercase "intendra ai" as a locked logotype — don't retype the logo as running text in place of the logo file, but do write the brand name as "Intendra AI" in prose).
- **Person**: no first-person plural product copy was observed in the source; guideline prose uses "Our wordmark," "Our symbol," "Our primary colors" when talking about the brand itself. For product UI copy, default to direct address ("Your customers," "your accounts") and system statements in third person ("3 new signals"), avoiding "I"/"we" inside the product.
- **Emoji**: none observed anywhere in source materials. Do not introduce emoji into Intendra AI product or marketing surfaces.
- **Numerals**: guideline type specimens show numerals set plainly (1234567890) with no special treatment — no forced tabular styling implied, but dashboards should still use tabular figures for scannability (a UI convention, not a documented brand rule).

## Visual Foundations

**Colors.** Four primary colors carry the brand: Brilliant Green `#1BEA87` (energetic, forward-thinking — the one true accent/CTA color), Stone `#E0E0E0` (neutral surface), Graphite `#4E525B` (secondary text/stable), Obsidian `#28282D` (near-black, primary text and dark surfaces). Five secondary colors — Aqua Circuit, Neural Violet, Lime Insight, Teal Flow, Cloud Mist — are explicitly for **sparing use as transparent overlays/highlights only**, never as dominant colors. The guideline is explicit that secondary colors "should never overpower the primary palette" and must never be used for the wordmark/symbol. No red/error color exists in the brand kit; a danger color was derived via oklch (see tokens/colors.css) rather than invented from scratch.

**Type.** One typeface family, Acumin Pro, in five weights (Light through Bold), used for both display and body — no serif, no secondary display face. Display line breaks are short, centered-on-meaning couplets ("Eliminating friction. / Activating insight."), not long paragraphs. **Font substitution flagged**: Acumin Pro is an Adobe-licensed font not available as a webfont; `tokens/typography.css` substitutes **Hanken Grotesk** (a free, similarly warm neo-grotesque) as the nearest open match. Please share Acumin Pro's web font files (or an Adobe Fonts/Typekit kit ID) if pixel-accurate type is needed.

**Spacing.** No spacing scale is defined in the brand guide; `tokens/spacing.css` uses a 4px-based scale (4/8/12/16/20/24/32/40/48/64/80/96), which pairs cleanly with the guideline's own clearspace rule (clearspace = one full wordmark height).

**Backgrounds.** The guide shows the wordmark/symbol only on flat light, flat dark, or photography backgrounds — no gradients, no patterns, no textures anywhere in the source. Keep backgrounds flat; when a background photo is used, the wordmark must switch to Stone or Brilliant Green and legibility takes priority over color fidelity.

**Imagery.** The only non-logo image supplied (`Reveal Big.png`) is a flat-color geometric starburst using the secondary palette (teal/lime/cyan/violet) over a plain white ground with no photography, grain, or gradients — reinforcing that Intendra AI's visual language right now is geometric/flat rather than photographic.

**Animation.** Not specified in source material. Given the brand's "clarity and precision" tone, default to short, standard-easing transitions (see `--duration-fast/base/slow` and `--ease-standard/out` tokens) — no bounce, no elaborate motion.

**Hover / press states.** Not specified in source; components here use a darkened accent step for hover (`--accent-hover #17C973`) and a further darkened step for press (`--accent-active #13AD62`), consistent with Brilliant Green being the one CTA color the guide reserves for action.

**Borders & shadows.** Not specified in source; a restrained, low-elevation shadow scale was authored in `tokens/shadows.css` (soft, single-direction, Obsidian-tinted rather than pure black) and a 1px `--border-default` in a neutral gray a shade darker than Stone, since Stone itself is too light to read as a border on white.

**Corner radii.** The symbol mark itself is built from squared blocks with **one rounded outer corner** (roughly a 20–25% corner radius relative to the block) — this "one-corner-round" geometry is the brand's signature shape language. `--radius-symbol: 22%` captures it for reuse in brand-adjacent shapes; UI components use a conventional 6–16px radius scale instead (not documented by the guide, sized for a typical dashboard UI).

**Transparency / blur.** The guide explicitly describes secondary colors as usable "as transparent overlays" that create new blended hues when layered — the only documented use of transparency in the brand. No blur/glass effects appear anywhere in source material.

**Cards.** Not documented in source; `components/surfaces/Card.jsx` uses a flat white surface, 1px `--border-default`, `--radius-lg`, and `--shadow-sm` — a plain, unbranded card since the guide gives no card precedent.

**Layout rules.** The one explicit layout rule: the wordmark alone sits in a page/document corner; wordmark + symbol together always place the wordmark top-left and the symbol top-right, never centered horizontally.

## Iconography
No icon system, icon font, or SVG icon set was found in any provided source (brand guide, deck, or logo files). Per design-system guidance, icons in the UI kit and component set use **Lucide** (CDN, `unpkg.com/lucide-static`), an open, closest-match stroke icon set (regular 1.5–2px stroke, no fill) — flagged here as a substitution, not a documented Intendra AI choice. No emoji or Unicode-glyph icons appear anywhere in source material, and none should be introduced.

## Index
- `styles.css` — root stylesheet, imports everything under `tokens/`.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `radii.css`, `shadows.css`.
- `assets/logo/` — wordmark + symbol, 4 color variants each (brilliant green, obsidian, stone, white).
- `assets/illustration/reveal-starburst.png` — the supplied starburst graphic.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand) shown in the Design System tab.
- `components/forms/` — Button, IconButton, Input, Select, Checkbox, Radio, Switch.
- `components/feedback/` — Badge, Tag, Toast, Tooltip.
- `components/surfaces/` — Card, Dialog.
- `components/navigation/` — Tabs.
- `ui_kits/dashboard/` — cosmetic recreation of a customer-behavior-intelligence dashboard (login, overview, signals feed, action board).
- `SKILL.md` — portable Agent Skill wrapper for this design system.
